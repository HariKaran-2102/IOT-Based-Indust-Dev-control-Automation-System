
void lcd_init(void);
void lcd_command(unsigned char);
void lcd_data(unsigned char);
void lcd_int(int);
void lcd_str(unsigned char *);
void delay_ms(unsigned char);

#define lcd 0xff<<10
#define RS 1<<8
#define E 1<<9

void lcd_init(void)
{
	IODIR0|=lcd|RS|E;
	lcd_command(0x01);
	lcd_command(0x02);
	lcd_command(0x0c);
	lcd_command(0x38);
}

void lcd_command(unsigned char c)
{
	IOCLR0=lcd;
	IOSET0=c<<10;
	IOCLR0=RS;
	IOSET0=E;
	delay_ms(2);
	IOCLR0=E;
}

void lcd_data(unsigned char d)
{
	IOCLR0=lcd;
	IOSET0=d<<10;
	IOSET0=RS;
	IOSET0=E;
	delay_ms(2);
	IOCLR0=E;
}


void lcd_int(int n)
{
	int i=0;
	char arr[5];
	if(n==0)
	lcd_data('0');
	else
	{
		if(n<0)
		{
			lcd_data('-');
			n=-n;
			}
		while(n>0)
		{
			arr[i++]=n%10;
			n=n/10;
		}
		for(--i;i>=0;i--)
		lcd_data(arr[i]+48);
	}
}

void lcd_str(unsigned char *s)
{
	while(*s)
	lcd_data(*s++);
}

void delay_ms(unsigned char n)
{
	T0PR=15000-1;
	T0TCR=0x01;
	while(T0TC<n);
	T0TCR=0x03;
	T0TCR=0x00;
}
void delay_s(unsigned char n)
{
	T0PR=15000000-1;
	T0TCR=0x01;
	while(T0TC<n);
	T0TCR=0x03;
	T0TCR=0x00;
}

