#include<lpc21xx.h>
#include"lcd_header.h"
#include"uart0_header.h"
#define op1 1<<4
#define op2 1<<5
#define op3 1<<6
#define op4 1<<7                           

int main()
{
	unsigned char n;
	IODIR0|=op1|op2|op3|op4;
	IOSET0 =op1|op2|op3|op4;
	lcd_init();
	uart0_init();
	lcd_command(0x80);
	lcd_str("IOT BASED INDUSTRIAL");
	lcd_command(0xc0);
	lcd_str("DEVICE CONTROL & ");
	lcd_command(0x94);
	lcd_str("AUTOMATION SYSTEM");

	while(1)
	{
		n=uart0_rx();
		if(n=='1')
		{
			IOCLR0|=op1;
			lcd_command(0xD4);
			lcd_str("Lamp1 is on  ");
		}
		else if(n=='3')
		{
			IOCLR0|=op2;
			lcd_command(0xD4);
			lcd_str("Lamp2 is on  ");
		}
		else if(n=='5')
		{
			IOCLR0|=op3;
			lcd_command(0xD4);
			lcd_str("Lamp3 is on  ");
		}
		else if(n=='7')
		{
			IOCLR0|=op4;
			lcd_command(0xD4);
			lcd_str("Lamp4 is on  ");
		}
		else if(n=='2')
		{
			IOSET0|=op1;
			lcd_command(0xD4);
			lcd_str("Lamp1 is off");
		}
		else if(n=='4')
		{
			IOSET0|=op2;
			lcd_command(0xD4);
			lcd_str("Lamp2 is off");
		}
		else if(n=='6')
		{
			IOSET0|=op3;
			lcd_command(0xD4);
			lcd_str("Lamp3 is off");
		}
		else if(n=='8')
		{
			IOSET0|=op4;
			lcd_command(0xD4);
			lcd_str("Lamp4 is off");
		}
	}
}

