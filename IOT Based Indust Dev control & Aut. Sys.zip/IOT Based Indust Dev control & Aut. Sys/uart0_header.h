void uart0_init(void);
unsigned char uart0_rx(void);
void uart0_init()
{
	PINSEL0=0x05;
	U0LCR=0x83;
	U0DLL=97;
	U0DLM=0;
	U0LCR=0x03;
}
unsigned char uart0_rx()
{
	while((U0LSR&1)==0);
	return U0RBR;
		
}

