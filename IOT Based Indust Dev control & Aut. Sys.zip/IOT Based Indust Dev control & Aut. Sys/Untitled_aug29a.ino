#include "arduino_secrets.h"

#include "arduino_secrets.h"
#include "thingProperties.h"
#define UART_BAUD 9600

void setup()
{

  Serial.begin(UART_BAUD);

  delay(1500);

  initProperties();

  ArduinoCloud.begin(ArduinoIoTPreferredConnection);

  setDebugMessageLevel(0);

  delay(1000);
}


void loop()
{
  ArduinoCloud.update();
}
void onSw1Change()
{
  if (sw1)
  {
    Serial.print('1');
  }
  else
  {
    Serial.print("2");
  }
}
void onSw2Change()
{
  if (sw2)
  {
    Serial.print('3');
  }
  else
  {
    Serial.print('4');
  }
}
void onSw3Change()
{
  if (sw3)
  {
    Serial.print('5');
  }
  else
  {
    Serial.print('6');
  }
}
void onSw4Change()
{
  if (sw4)
  {
    Serial.print('7');
  }
  else
  {
    Serial.print('8');
  }
}
